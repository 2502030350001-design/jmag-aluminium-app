# APK Build Instructions

This app is ready as an offline web app/PWA in this folder.

To create a real Android APK, install Android Studio or Android SDK build tools, then wrap this folder with Capacitor, Cordova, or an Android WebView shell.

Recommended path:

1. Install Android Studio.
2. Create a new Android project with one WebView activity.
3. Copy all files from this `outputs` folder into Android `app/src/main/assets/www`.
4. Load `file:///android_asset/www/index.html` in the WebView.
5. Build a signed APK from Android Studio.

The current environment does not include Java, Gradle, Android SDK, `apksigner`, or `zipalign`, so a signed `.apk` cannot be produced locally here yet.
