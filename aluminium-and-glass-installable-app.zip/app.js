const DEDUCTION_MASTER = {
  threeQuarter: {
    label: "3/4 Section Window",
    bearingDeductions: {
      big: -1.5,
      small: -1.37,
    },
    trackDeductions: {
      "2 Track": -6.5,
      "3 Track": -8.13,
      "4 Track": -9.75,
      "2+2": -11.5,
      "3+3": -14.25,
    },
    glassDeductions: {
      width: -0.63,
      height: -2.5,
    },
  },
  sixtyMm: {
    label: "60mm Section Window",
    bearingDeductions: {
      big: -1.5,
      small: -1.37,
    },
    trackDeductions: {
      "2 Track": 0.5,
      "3T Single Groove": 3.13,
      "3T Double Groove": 2.5,
      "4T Single Groove": 5.25,
      "4T Double Groove": 4.5,
      "2+2": 2.75,
      "3+3": 7.5,
    },
    glassDeductions: {
      width: -4.13,
      height: -4.13,
    },
  },
  domalBancoNational: {
    label: "27x65 Domal Banco/National",
    heightDeduction: -2.75,
    trackDeductions: {
      "2 Track": -0.5,
      "3 Track": 1.87,
      "4 Track": 4.63,
      "2+2": 1.75,
      "3+3": 7,
    },
    glassDeductions: {
      width: -4.13,
      height: -4.13,
    },
  },
  domalJindal: {
    label: "27x65 Domal Jindal",
    heightDeduction: -3,
    trackDeductions: {
      "2 Track": -0.75,
      "3 Track": 1.5,
      "4 Track": 4.37,
      "2+2": 1.5,
      "3+3": 6.5,
    },
    glassDeductions: {
      width: -4.13,
      height: -4.13,
    },
  },
  jindalCardinal25x65: {
    label: "25x65 Jindal Cardinal",
    heightDeduction: -2.5,
    trackDeductions: {
      "2 Track": -0.37,
      "3 Track": 1.87,
      "4 Track": 1.25,
    },
    glassDeductions: {
      width: -4.25,
      height: -4.25,
    },
  },
  jindalCardinal29x65: {
    label: "29x65 Jindal Cardinal",
    heightDeduction: -3.13,
    trackDeductions: {
      "2 Track": -0.5,
      "3 Track": 1.75,
      "4 Track": 4.5,
      "2+2": 1.75,
    },
    glassDeductions: {
      width: -4.13,
      height: -4.13,
    },
  },
};

const FABRICATION_CONFIG = {
  trackPanels: {
    "2 Track": 2,
    "3 Track": 3,
    "4 Track": 4,
    "2+2": 4,
    "3+3": 6,
    "3T Single Groove": 3,
    "3T Double Groove": 3,
    "4T Single Groove": 4,
    "4T Double Groove": 4,
  },
  materialGroups: {
    frame: "Frame Material",
    shutter: "Shutter Material",
    interlock: "Interlock Material",
    aluminium: "Aluminium Length",
    glassPieces: "Glass Pieces",
    glassArea: "Glass Area",
    hardware: "Hardware Quantities",
  },
};

const DEFAULT_RATES = {
  bancoRate: 180,
  jindalRate: 220,
  cardinalRate: 240,
  sixtyMmRate: 260,
  threeQuarterRate: 160,
  glass4mmRate: 55,
  glass5mmRate: 70,
  glass8mmRate: 110,
  glass10mmRate: 145,
  customGlassRate: 90,
  rollerRate: 45,
  lockRate: 120,
  handleRate: 80,
  woolPileRate: 5,
  rubberRate: 7,
  screwRate: 1.5,
  labourRate: 35,
  transport: 0,
  installation: 0,
  miscellaneous: 0,
  gstPercent: 18,
};

const RATE_FIELDS = [
  ["Aluminium Rates", [["Banco Rate", "bancoRate"], ["Jindal Rate", "jindalRate"], ["Cardinal Rate", "cardinalRate"], ["60mm Rate", "sixtyMmRate"], ["3/4 Section Rate", "threeQuarterRate"]]],
  ["Glass Rates", [["4mm Rate", "glass4mmRate"], ["5mm Rate", "glass5mmRate"], ["8mm Rate", "glass8mmRate"], ["10mm Rate", "glass10mmRate"], ["Custom Rate", "customGlassRate"]]],
  ["Hardware Rates", [["Roller Rate", "rollerRate"], ["Lock Rate", "lockRate"], ["Handle Rate", "handleRate"], ["Wool Pile Rate", "woolPileRate"], ["Rubber Rate", "rubberRate"], ["Screw Rate", "screwRate"]]],
  ["Labour & Charges", [["Labour Rate per sq.ft", "labourRate"], ["Transport", "transport"], ["Installation", "installation"], ["Miscellaneous", "miscellaneous"], ["GST %", "gstPercent"]]],
];

const DEFAULT_SETTINGS = {
  companyName: "Aluminium And Glass",
  logoText: "AW",
  currency: "Rs.",
  printFooter: "Thank you for your business.",
};

const STORAGE_KEYS = {
  projects: "afms.projects",
  activeProject: "afms.activeProject",
  rates: "afms.rates",
  settings: "afms.settings",
  theme: "afms.theme",
  history: "afms.history",
  quotations: "afms.quotations",
  companyLogo: "companyLogo",
  letterheadPDF: "letterheadPDF",
};

const $ = (selector) => document.querySelector(selector);
const els = {
  loadingOverlay: $("#loadingOverlay"),
  logoBox: $("#logoBox"),
  companyTitle: $("#companyTitle"),
  themeToggle: $("#themeToggle"),
  clearAllButton: $("#clearAllButton"),
  projectCount: $("#projectCount"),
  windowCount: $("#windowCount"),
  quotationCount: $("#quotationCount"),
  recentActivity: $("#recentActivity"),
  clientName: $("#clientName"),
  clientMobile: $("#clientMobile"),
  projectName: $("#projectName"),
  siteAddress: $("#siteAddress"),
  projectDate: $("#projectDate"),
  projectRemarks: $("#projectRemarks"),
  projectSearch: $("#projectSearch"),
  projectSelect: $("#projectSelect"),
  projectList: $("#projectList"),
  newProjectButton: $("#newProjectButton"),
  saveProjectButton: $("#saveProjectButton"),
  duplicateProjectButton: $("#duplicateProjectButton"),
  calculatorForm: $("#calculatorForm"),
  windowNumber: $("#windowNumber"),
  windowDescription: $("#windowDescription"),
  quantity: $("#quantity"),
  sectionType: $("#sectionType"),
  trackType: $("#trackType"),
  glassType: $("#glassType"),
  width: $("#width"),
  height: $("#height"),
  bearingGroup: $("#bearingGroup"),
  validationMessage: $("#validationMessage"),
  addWindowButton: $("#addWindowButton"),
  updateWindowButton: $("#updateWindowButton"),
  clearWindowFormButton: $("#clearWindowFormButton"),
  windowRows: $("#windowRows"),
  frameWidthCard: $("#frameWidthCard"),
  frameHeightCard: $("#frameHeightCard"),
  glassWidthCard: $("#glassWidthCard"),
  glassHeightCard: $("#glassHeightCard"),
  resultRows: $("#resultRows"),
  copyButton: $("#copyButton"),
  copyStatus: $("#copyStatus"),
  pdfButton: $("#pdfButton"),
  cuttingRows: $("#cuttingRows"),
  materialRows: $("#materialRows"),
  glassRows: $("#glassRows"),
  glassTotals: $("#glassTotals"),
  rateFields: $("#rateFields"),
  saveRatesButton: $("#saveRatesButton"),
  resetRatesButton: $("#resetRatesButton"),
  exportRatesButton: $("#exportRatesButton"),
  importRatesInput: $("#importRatesInput"),
  profitPercent: $("#profitPercent"),
  itemDescription: $("#itemDescription"),
  rateSnapshotStatus: $("#rateSnapshotStatus"),
  quotationRows: $("#quotationRows"),
  quotationTotals: $("#quotationTotals"),
  historySearch: $("#historySearch"),
  historyFilter: $("#historyFilter"),
  historyList: $("#historyList"),
  companyName: $("#companyName"),
  companyLogoText: $("#companyLogoText"),
  companyLogoInput: $("#companyLogoInput"),
  letterheadPdfInput: $("#letterheadPdfInput"),
  brandingStatus: $("#brandingStatus"),
  currencySymbol: $("#currencySymbol"),
  printFooter: $("#printFooter"),
  saveSettingsButton: $("#saveSettingsButton"),
};

let activeProject = createBlankProject();
let editingWindowId = null;

function calculateWindow({ sectionKey, width, height, quantity, track, bearingType }) {
  const section = DEDUCTION_MASTER[sectionKey];
  const frameWidth = width + section.trackDeductions[track];
  const frameHeight = height + getHeightDeduction(section, bearingType);
  const glassWidth = frameWidth + section.glassDeductions.width;
  const glassHeight = frameHeight + section.glassDeductions.height;

  return {
    section,
    sectionKey,
    track,
    bearingType: section.bearingDeductions ? bearingType : "notApplicable",
    quantity,
    frameWidth,
    frameHeight,
    glassWidth,
    glassHeight,
    deductions: {
      track: section.trackDeductions[track],
      height: getHeightDeduction(section, bearingType),
      glassWidth: section.glassDeductions.width,
      glassHeight: section.glassDeductions.height,
    },
  };
}

function getHeightDeduction(section, bearingType) {
  if (section.bearingDeductions) return section.bearingDeductions[bearingType];
  return section.heightDeduction;
}

function createBlankProject() {
  return {
    id: Date.now(),
    clientName: "",
    mobile: "",
    siteAddress: "",
    projectName: "New Aluminium Project",
    date: new Date().toISOString().slice(0, 10),
    remarks: "",
    windows: [],
    rateSnapshot: null,
    createdAt: new Date().toISOString(),
    updatedAt: new Date().toISOString(),
  };
}

function readJson(key, fallback) {
  try {
    return JSON.parse(localStorage.getItem(key)) ?? fallback;
  } catch {
    return fallback;
  }
}

function writeJson(key, value) {
  localStorage.setItem(key, JSON.stringify(value));
}

function formatNumber(value) {
  return Number((Number(value) || 0).toFixed(2)).toString();
}

function parseMeasurement(value) {
  const raw = String(value || "").trim().replace(/-/g, " ");
  if (!raw) return NaN;
  const parts = raw.split(/\s+/);
  let total = 0;
  for (const part of parts) {
    if (part.includes("/")) {
      const [n, d] = part.split("/").map(Number);
      if (!Number.isFinite(n) || !Number.isFinite(d) || d === 0) return NaN;
      total += n / d;
    } else {
      const number = Number(part);
      if (!Number.isFinite(number)) return NaN;
      total += number;
    }
  }
  return total;
}

function escapeHtml(value) {
  return String(value ?? "")
    .replaceAll("&", "&amp;")
    .replaceAll("<", "&lt;")
    .replaceAll(">", "&gt;")
    .replaceAll('"', "&quot;")
    .replaceAll("'", "&#039;");
}

function getSettings() {
  const settings = { ...DEFAULT_SETTINGS, ...readJson(STORAGE_KEYS.settings, {}) };
  if (settings.companyName === "Aluminium Fabrication Works") {
    settings.companyName = "Aluminium And Glass";
    writeJson(STORAGE_KEYS.settings, settings);
  }
  return settings;
}

function getRates() {
  return { ...DEFAULT_RATES, ...readJson(STORAGE_KEYS.rates, {}) };
}

function getProjects() {
  return readJson(STORAGE_KEYS.projects, []);
}

function saveProjects(projects) {
  writeJson(STORAGE_KEYS.projects, projects);
}

function getSelectedBearing() {
  return els.calculatorForm.elements.bearingType.value;
}

function getTrackPanelCount(track) {
  return FABRICATION_CONFIG.trackPanels[track] || 2;
}

function getSectionRate(sectionKey, rates) {
  const section = DEDUCTION_MASTER[sectionKey]?.label || "";
  if (section.includes("Banco")) return rates.bancoRate;
  if (section.includes("60mm")) return rates.sixtyMmRate;
  if (section.includes("3/4")) return rates.threeQuarterRate;
  if (section.includes("Cardinal")) return rates.cardinalRate;
  return rates.jindalRate;
}

function getGlassRate(glassType, rates) {
  const map = {
    "4mm": rates.glass4mmRate,
    "5mm": rates.glass5mmRate,
    "8mm": rates.glass8mmRate,
    "10mm": rates.glass10mmRate,
    custom: rates.customGlassRate,
  };
  return map[glassType] || rates.glass5mmRate;
}

function populateSections() {
  els.sectionType.innerHTML = Object.entries(DEDUCTION_MASTER)
    .map(([key, section]) => `<option value="${key}">${escapeHtml(section.label)}</option>`)
    .join("");
  els.historyFilter.innerHTML = '<option value="">All Sections</option>' + Object.values(DEDUCTION_MASTER)
    .map((section) => `<option value="${escapeHtml(section.label)}">${escapeHtml(section.label)}</option>`)
    .join("");
}

function syncTrackOptions() {
  const section = DEDUCTION_MASTER[els.sectionType.value];
  const current = els.trackType.value;
  const tracks = Object.keys(section.trackDeductions);
  els.trackType.innerHTML = tracks.map((track) => `<option value="${escapeHtml(track)}">${escapeHtml(track)}</option>`).join("");
  if (tracks.includes(current)) els.trackType.value = current;
}

function syncBearingVisibility() {
  const section = DEDUCTION_MASTER[els.sectionType.value];
  els.bearingGroup.hidden = !section.bearingDeductions;
}

function getWindowFormData() {
  const width = parseMeasurement(els.width.value);
  const height = parseMeasurement(els.height.value);
  return {
    id: editingWindowId || Date.now(),
    number: els.windowNumber.value.trim() || `W${activeProject.windows.length + 1}`,
    description: els.windowDescription.value.trim() || "Window",
    sectionKey: els.sectionType.value,
    track: els.trackType.value,
    bearingType: getSelectedBearing(),
    glassType: els.glassType.value,
    widthInput: els.width.value.trim(),
    heightInput: els.height.value.trim(),
    width,
    height,
    quantity: Number(els.quantity.value),
  };
}

function validateWindow(win) {
  if (!DEDUCTION_MASTER[win.sectionKey]) return "Select a valid section type.";
  if (!Number.isFinite(win.width) || win.width <= 0) return "Width must be a valid positive number or fraction.";
  if (!Number.isFinite(win.height) || win.height <= 0) return "Height must be a valid positive number or fraction.";
  if (!Number.isInteger(win.quantity) || win.quantity <= 0) return "Quantity must be a whole number greater than 0.";
  if (!DEDUCTION_MASTER[win.sectionKey].trackDeductions.hasOwnProperty(win.track)) return "Select a valid track type.";
  return "";
}

function calculateWindowRecord(win) {
  const result = calculateWindow({
    sectionKey: win.sectionKey,
    width: win.width,
    height: win.height,
    quantity: win.quantity,
    track: win.track,
    bearingType: win.bearingType,
  });
  const panels = getTrackPanelCount(win.track);
  const glassAreaSqFt = (result.glassWidth * result.glassHeight * win.quantity) / 144;
  return {
    ...win,
    sectionLabel: result.section.label,
    frameVertical: result.frameHeight,
    frameHorizontal: result.frameWidth,
    shutterVertical: result.glassHeight,
    shutterHorizontal: result.glassWidth,
    interlock: result.frameHeight,
    glassWidth: result.glassWidth,
    glassHeight: result.glassHeight,
    glassAreaSqFt,
    glassAreaSqM: glassAreaSqFt * 0.092903,
    panels,
    result,
  };
}

function getCalculatedWindows() {
  return activeProject.windows.map(calculateWindowRecord);
}

function addWindow() {
  const win = getWindowFormData();
  const error = validateWindow(win);
  els.validationMessage.textContent = error;
  if (error) return;
  activeProject.windows.push({ ...win, id: Date.now() });
  activeProject.rateSnapshot ||= getRates();
  editingWindowId = null;
  clearWindowForm(false);
  renderAll("Window added");
}

function updateWindow() {
  if (!editingWindowId) {
    els.validationMessage.textContent = "Select a window to edit first.";
    return;
  }
  const win = getWindowFormData();
  const error = validateWindow(win);
  els.validationMessage.textContent = error;
  if (error) return;
  activeProject.windows = activeProject.windows.map((item) => item.id === editingWindowId ? win : item);
  editingWindowId = null;
  clearWindowForm(false);
  renderAll("Window updated");
}

function editWindow(id) {
  const win = activeProject.windows.find((item) => item.id === id);
  if (!win) return;
  editingWindowId = id;
  els.windowNumber.value = win.number;
  els.windowDescription.value = win.description;
  els.quantity.value = win.quantity;
  els.sectionType.value = win.sectionKey;
  syncTrackOptions();
  els.trackType.value = win.track;
  els.glassType.value = win.glassType || "5mm";
  els.width.value = win.widthInput || win.width;
  els.height.value = win.heightInput || win.height;
  els.calculatorForm.elements.bearingType.value = win.bearingType;
  syncBearingVisibility();
  els.validationMessage.textContent = "";
}

function deleteWindow(id) {
  activeProject.windows = activeProject.windows.filter((win) => win.id !== id);
  renderAll("Window deleted");
}

function duplicateWindow(id) {
  const win = activeProject.windows.find((item) => item.id === id);
  if (!win) return;
  activeProject.windows.push({ ...win, id: Date.now(), number: `${win.number} Copy` });
  renderAll("Window duplicated");
}

function clearWindowForm(resetNumber = true) {
  if (resetNumber) editingWindowId = null;
  if (resetNumber) els.windowNumber.value = `W${activeProject.windows.length + 1}`;
  els.windowDescription.value = "Sliding window";
  els.quantity.value = "1";
  els.width.value = "48";
  els.height.value = "60";
  els.glassType.value = "5mm";
  els.validationMessage.textContent = "";
  syncBearingVisibility();
}

function renderWindowRows(calculated) {
  if (!activeProject.windows.length) {
    els.windowRows.innerHTML = '<tr><td colspan="9">No windows added yet.</td></tr>';
    return;
  }
  els.windowRows.innerHTML = calculated.map((win) => `
    <tr>
      <td>${escapeHtml(win.number)}</td>
      <td>${escapeHtml(win.description)}</td>
      <td>${escapeHtml(win.sectionLabel)}</td>
      <td>${escapeHtml(win.track)}</td>
      <td>${win.result.bearingType === "notApplicable" ? "N/A" : escapeHtml(win.bearingType)}</td>
      <td>${formatNumber(win.width)}</td>
      <td>${formatNumber(win.height)}</td>
      <td>${win.quantity}</td>
      <td class="row-actions">
        <button class="mini-button" type="button" data-window-edit="${win.id}">Edit</button>
        <button class="mini-button" type="button" data-window-copy="${win.id}">Duplicate</button>
        <button class="mini-button danger-mini" type="button" data-window-delete="${win.id}">Delete</button>
      </td>
    </tr>
  `).join("");
}

function buildCuttingSchedule(calculated) {
  return calculated.flatMap((win) => {
    const q = win.quantity;
    const interlockQty = Math.max(win.panels - 1, 1) * q;
    return [
      ["Frame", win.number, "Frame Vertical", win.frameVertical, 2 * q],
      ["Frame", win.number, "Frame Horizontal", win.frameHorizontal, 2 * q],
      ["Shutter", win.number, "Shutter Vertical", win.shutterVertical, win.panels * 2 * q],
      ["Shutter", win.number, "Shutter Horizontal", win.shutterHorizontal, win.panels * 2 * q],
      ["Interlock", win.number, "Interlock", win.interlock, interlockQty],
      ["Other Profiles", win.number, "Track Channel", win.frameHorizontal, win.panels * q],
    ].map(([group, windowNo, member, size, quantity]) => ({
      group,
      windowNo,
      member,
      size,
      quantity,
      total: size * quantity,
    }));
  });
}

function buildMaterialSummary(calculated) {
  const rows = calculated.reduce((acc, win) => {
    const q = win.quantity;
    acc.frame += (2 * win.frameVertical + 2 * win.frameHorizontal) * q;
    acc.shutter += (2 * win.shutterVertical + 2 * win.shutterHorizontal) * win.panels * q;
    acc.interlock += win.interlock * Math.max(win.panels - 1, 1) * q;
    acc.channel += win.frameHorizontal * win.panels * q;
    acc.glassPieces += win.panels * q;
    acc.glassArea += win.glassAreaSqFt;
    acc.rollers += win.panels * 2 * q;
    acc.locks += q;
    acc.handles += win.panels * q;
    acc.woolPile += (2 * win.shutterVertical + 2 * win.shutterHorizontal) * win.panels * q;
    acc.rubber += (2 * win.glassWidth + 2 * win.glassHeight) * win.panels * q;
    acc.screws += 8 * q;
    return acc;
  }, { frame: 0, shutter: 0, interlock: 0, channel: 0, glassPieces: 0, glassArea: 0, rollers: 0, locks: 0, handles: 0, woolPile: 0, rubber: 0, screws: 0 });
  rows.aluminium = rows.frame + rows.shutter + rows.interlock + rows.channel;
  return rows;
}

function buildGlassSummary(calculated) {
  const groups = new Map();
  calculated.forEach((win) => {
    const qty = win.panels * win.quantity;
    const key = `${formatNumber(win.glassWidth)} x ${formatNumber(win.glassHeight)}`;
    const current = groups.get(key) || { width: win.glassWidth, height: win.glassHeight, quantity: 0, area: 0 };
    current.quantity += qty;
    current.area += (win.glassWidth * win.glassHeight * qty) / 144;
    groups.set(key, current);
  });
  return Array.from(groups.values());
}

function buildQuotation(calculated, material, glassSummary) {
  const rates = activeProject.rateSnapshot || getRates();
  const settings = getSettings();
  const aluminiumCost = calculated.reduce((sum, win) => sum + ((
    (2 * win.frameVertical + 2 * win.frameHorizontal) * win.quantity +
    (2 * win.shutterVertical + 2 * win.shutterHorizontal) * win.panels * win.quantity +
    win.interlock * Math.max(win.panels - 1, 1) * win.quantity +
    win.frameHorizontal * win.panels * win.quantity
  ) / 12) * getSectionRate(win.sectionKey, rates), 0);
  const glassCost = calculated.reduce((sum, win) => {
    const pieces = win.panels * win.quantity;
    const area = (win.glassWidth * win.glassHeight * pieces) / 144;
    return sum + area * getGlassRate(win.glassType, rates);
  }, 0);
  const hardwareCost =
    material.rollers * rates.rollerRate +
    material.locks * rates.lockRate +
    material.handles * rates.handleRate +
    material.woolPile * rates.woolPileRate +
    material.rubber * rates.rubberRate +
    material.screws * rates.screwRate;
  const labourCost = material.glassArea * rates.labourRate;
  const otherCharges = rates.transport + rates.installation + rates.miscellaneous;
  const base = aluminiumCost + glassCost + hardwareCost + labourCost + otherCharges;
  const profit = base * ((Number(els.profitPercent.value) || 0) / 100);
  const subtotal = base + profit;
  const gst = subtotal * ((Number(rates.gstPercent) || 0) / 100);
  return {
    currency: settings.currency,
    aluminiumCost,
    glassCost,
    hardwareCost,
    labourCost,
    otherCharges,
    profit,
    subtotal,
    gst,
    grandTotal: subtotal + gst,
    glassSummary,
  };
}

function renderCalculations(calculated) {
  const first = calculated[0];
  els.frameWidthCard.textContent = first ? formatNumber(first.frameHorizontal) : "0";
  els.frameHeightCard.textContent = first ? formatNumber(first.frameVertical) : "0";
  els.glassWidthCard.textContent = first ? formatNumber(first.glassWidth) : "0";
  els.glassHeightCard.textContent = first ? formatNumber(first.glassHeight) : "0";
  if (!calculated.length) {
    els.resultRows.innerHTML = '<tr><td colspan="14">Add windows to generate calculations.</td></tr>';
    return;
  }
  els.resultRows.innerHTML = calculated.map((win) => `
    <tr>
      <td>${escapeHtml(win.number)}</td>
      <td>${escapeHtml(win.sectionLabel)}</td>
      <td>${formatNumber(win.width)}</td>
      <td>${formatNumber(win.height)}</td>
      <td>${win.quantity}</td>
      <td>${escapeHtml(win.track)}</td>
      <td>${formatNumber(win.frameVertical * win.quantity)}</td>
      <td>${formatNumber(win.frameHorizontal * win.quantity)}</td>
      <td>${formatNumber(win.shutterVertical * win.panels * win.quantity)}</td>
      <td>${formatNumber(win.shutterHorizontal * win.panels * win.quantity)}</td>
      <td>${formatNumber(win.interlock * Math.max(win.panels - 1, 1) * win.quantity)}</td>
      <td>${formatNumber(win.glassWidth)}</td>
      <td>${formatNumber(win.glassHeight)}</td>
      <td>${formatNumber(win.glassAreaSqFt)} sq ft</td>
    </tr>
  `).join("");
}

function renderCutting(rows) {
  els.cuttingRows.innerHTML = rows.length ? rows.map((row) => `
    <tr>
      <td>${escapeHtml(row.group)}</td><td>${escapeHtml(row.windowNo)}</td><td>${escapeHtml(row.member)}</td>
      <td>${formatNumber(row.size)}</td><td>${row.quantity}</td><td>${formatNumber(row.total)}</td>
    </tr>
  `).join("") : '<tr><td colspan="6">No cutting schedule yet.</td></tr>';
}

function renderMaterial(material) {
  const rows = [
    ["Frame Material", material.frame, "inches"],
    ["Shutter Material", material.shutter, "inches"],
    ["Interlock Material", material.interlock, "inches"],
    ["Channel Material", material.channel, "inches"],
    ["Aluminium Length", material.aluminium, "inches"],
    ["Glass Pieces", material.glassPieces, "pcs"],
    ["Glass Area", material.glassArea, "sq ft"],
    ["Rollers", material.rollers, "pcs"],
    ["Locks", material.locks, "pcs"],
    ["Handles", material.handles, "pcs"],
    ["Wool Pile", material.woolPile, "inches"],
    ["Rubber", material.rubber, "inches"],
    ["Screws", material.screws, "pcs"],
  ];
  els.materialRows.innerHTML = rows.map(([name, total, unit]) => `<tr><td>${name}</td><td>${formatNumber(total)}</td><td>${unit}</td></tr>`).join("");
}

function renderGlass(glassRows) {
  const totalSqFt = glassRows.reduce((sum, row) => sum + row.area, 0);
  els.glassRows.innerHTML = glassRows.length ? glassRows.map((row) => `
    <tr><td>${formatNumber(row.width)}</td><td>${formatNumber(row.height)}</td><td>${row.quantity}</td><td>${formatNumber(row.area)} sq ft</td></tr>
  `).join("") : '<tr><td colspan="4">No glass summary yet.</td></tr>';
  els.glassTotals.innerHTML = `
    <div class="total-pill"><span>Total Square Feet</span>${formatNumber(totalSqFt)}</div>
    <div class="total-pill"><span>Total Square Meters</span>${formatNumber(totalSqFt * 0.092903)}</div>
  `;
}

function renderQuotation(quote) {
  const rows = [
    ["Aluminium Cost", quote.aluminiumCost],
    ["Glass Cost", quote.glassCost],
    ["Hardware Cost", quote.hardwareCost],
    ["Labour Cost", quote.labourCost],
    ["Other Charges", quote.otherCharges],
    ["Profit", quote.profit],
    ["GST", quote.gst],
  ];
  els.quotationRows.innerHTML = rows.map(([name, amount]) => `<tr><td>${name}</td><td>${quote.currency} ${formatNumber(amount)}</td></tr>`).join("");
  els.quotationTotals.innerHTML = `
    <div class="total-pill"><span>Subtotal</span>${quote.currency} ${formatNumber(quote.subtotal)}</div>
    <div class="total-pill"><span>Grand Total</span>${quote.currency} ${formatNumber(quote.grandTotal)}</div>
  `;
  els.rateSnapshotStatus.value = activeProject.rateSnapshot ? "Saved inside project" : "Current rates";
}

function renderRates() {
  const rates = getRates();
  els.rateFields.innerHTML = RATE_FIELDS.map(([group, fields]) => `
    <section class="rate-card">
      <h3>${escapeHtml(group)}</h3>
      ${fields.map(([label, key]) => `
        <label class="field"><span>${escapeHtml(label)}</span><input data-rate-key="${key}" type="number" step="0.01" value="${rates[key]}" /></label>
      `).join("")}
    </section>
  `).join("");
}

function renderProjects() {
  const search = els.projectSearch.value.trim().toLowerCase();
  const projects = getProjects();
  const filtered = projects.filter((project) => `${project.projectName} ${project.clientName} ${project.mobile}`.toLowerCase().includes(search));
  els.projectSelect.innerHTML = '<option value="">Select saved project</option>' + projects
    .map((project) => `<option value="${project.id}">${escapeHtml(project.projectName)} - ${escapeHtml(project.clientName)}</option>`)
    .join("");
  els.projectList.innerHTML = filtered.length ? filtered.map((project) => `
    <article class="project-item">
      <div><strong>${escapeHtml(project.projectName)}</strong><span>${escapeHtml(project.clientName || "No client")} | ${escapeHtml(project.date || "")} | ${project.windows.length} windows</span></div>
      <div class="project-actions">
        <button class="mini-button" type="button" data-project-open="${project.id}">Open</button>
        <button class="mini-button" type="button" data-project-copy="${project.id}">Duplicate</button>
        <button class="mini-button danger-mini" type="button" data-project-delete="${project.id}">Delete</button>
      </div>
    </article>
  `).join("") : '<p class="module-empty">No projects found.</p>';
}

function renderHistory() {
  const search = els.historySearch.value.trim().toLowerCase();
  const filter = els.historyFilter.value;
  const history = readJson(STORAGE_KEYS.history, []);
  const filtered = history.filter((item) => {
    const text = `${item.projectName} ${item.clientName} ${item.sectionLabels.join(" ")}`.toLowerCase();
    return (!search || text.includes(search)) && (!filter || item.sectionLabels.includes(filter));
  });
  els.historyList.innerHTML = filtered.length ? filtered.map((item) => `
    <article class="history-item">
      <div><strong>${escapeHtml(item.projectName)}</strong><span>${escapeHtml(item.clientName)} | ${item.windowCount} windows | ${escapeHtml(item.savedAt)}</span></div>
      <div class="project-actions"><button class="mini-button" type="button" data-history-open="${item.projectId}">Reopen</button></div>
    </article>
  `).join("") : '<p class="module-empty">No history yet.</p>';
}

function renderProjectForm() {
  els.clientName.value = activeProject.clientName;
  els.clientMobile.value = activeProject.mobile;
  els.siteAddress.value = activeProject.siteAddress;
  els.projectName.value = activeProject.projectName;
  els.projectDate.value = activeProject.date;
  els.projectRemarks.value = activeProject.remarks;
}

function collectProjectForm() {
  activeProject.clientName = els.clientName.value.trim();
  activeProject.mobile = els.clientMobile.value.trim();
  activeProject.siteAddress = els.siteAddress.value.trim();
  activeProject.projectName = els.projectName.value.trim() || "Untitled Project";
  activeProject.date = els.projectDate.value;
  activeProject.remarks = els.projectRemarks.value.trim();
  activeProject.updatedAt = new Date().toISOString();
}

function renderAll(activity) {
  collectProjectForm();
  const calculated = getCalculatedWindows();
  const cutting = buildCuttingSchedule(calculated);
  const material = buildMaterialSummary(calculated);
  const glass = buildGlassSummary(calculated);
  const quote = buildQuotation(calculated, material, glass);
  renderWindowRows(calculated);
  renderCalculations(calculated);
  renderCutting(cutting);
  renderMaterial(material);
  renderGlass(glass);
  renderQuotation(quote);
  renderProjects();
  renderHistory();
  updateDashboard(activity);
}

function updateDashboard(activity) {
  const projects = getProjects();
  els.projectCount.textContent = projects.length;
  els.windowCount.textContent = projects.reduce((sum, project) => sum + project.windows.length, 0) + activeProject.windows.length;
  els.quotationCount.textContent = readJson(STORAGE_KEYS.quotations, []).length;
  if (activity) els.recentActivity.textContent = activity;
}

function saveProject({ duplicate = false } = {}) {
  collectProjectForm();
  if (!activeProject.rateSnapshot) activeProject.rateSnapshot = getRates();
  if (duplicate) {
    activeProject = { ...structuredClone(activeProject), id: Date.now(), projectName: `${activeProject.projectName} Copy`, updatedAt: new Date().toISOString() };
  }
  const projects = getProjects().filter((project) => project.id !== activeProject.id);
  projects.unshift(structuredClone(activeProject));
  saveProjects(projects);
  writeJson(STORAGE_KEYS.activeProject, activeProject.id);
  saveHistory();
  renderAll(duplicate ? "Project duplicated" : "Project saved");
}

function saveHistory() {
  const calculated = getCalculatedWindows();
  const item = {
    projectId: activeProject.id,
    projectName: activeProject.projectName,
    clientName: activeProject.clientName,
    windowCount: activeProject.windows.length,
    sectionLabels: [...new Set(calculated.map((win) => win.sectionLabel))],
    savedAt: new Date().toLocaleString(),
  };
  const history = readJson(STORAGE_KEYS.history, []).filter((entry) => entry.projectId !== activeProject.id);
  history.unshift(item);
  writeJson(STORAGE_KEYS.history, history.slice(0, 100));
}

function openProject(id) {
  const project = getProjects().find((item) => String(item.id) === String(id));
  if (!project) return;
  activeProject = structuredClone(project);
  editingWindowId = null;
  renderProjectForm();
  clearWindowForm();
  renderAll("Project opened");
}

function deleteProject(id) {
  saveProjects(getProjects().filter((project) => String(project.id) !== String(id)));
  if (String(activeProject.id) === String(id)) activeProject = createBlankProject();
  renderProjectForm();
  renderAll("Project deleted");
}

function duplicateSavedProject(id) {
  const project = getProjects().find((item) => String(item.id) === String(id));
  if (!project) return;
  const copy = structuredClone(project);
  copy.id = Date.now();
  copy.projectName = `${copy.projectName} Copy`;
  saveProjects([copy, ...getProjects()]);
  renderAll("Project duplicated");
}

function saveRates() {
  const rates = {};
  document.querySelectorAll("[data-rate-key]").forEach((input) => {
    rates[input.dataset.rateKey] = Number(input.value) || 0;
  });
  writeJson(STORAGE_KEYS.rates, rates);
  renderAll("Rates saved");
}

function resetRates() {
  writeJson(STORAGE_KEYS.rates, DEFAULT_RATES);
  renderRates();
  renderAll("Rates reset");
}

function exportRates() {
  downloadFile("aluminium-rates.json", JSON.stringify(getRates(), null, 2), "application/json");
}

function importRates(file) {
  if (!file) return;
  const reader = new FileReader();
  reader.onload = () => {
    try {
      writeJson(STORAGE_KEYS.rates, { ...DEFAULT_RATES, ...JSON.parse(reader.result) });
      renderRates();
      renderAll("Rates imported");
    } catch {
      els.recentActivity.textContent = "Import failed";
    }
  };
  reader.readAsText(file);
}

function saveSettings() {
  const settings = {
    companyName: els.companyName.value.trim() || DEFAULT_SETTINGS.companyName,
    logoText: els.companyLogoText.value.trim() || DEFAULT_SETTINGS.logoText,
    currency: els.currencySymbol.value.trim() || DEFAULT_SETTINGS.currency,
    printFooter: els.printFooter.value.trim() || DEFAULT_SETTINGS.printFooter,
  };
  writeJson(STORAGE_KEYS.settings, settings);
  applySettings();
  renderAll("Settings saved");
}

function applySettings() {
  const settings = getSettings();
  const companyLogo = localStorage.getItem(STORAGE_KEYS.companyLogo);
  els.companyName.value = settings.companyName;
  els.companyLogoText.value = settings.logoText;
  els.currencySymbol.value = settings.currency;
  els.printFooter.value = settings.printFooter;
  els.companyTitle.textContent = settings.companyName;
  els.logoBox.innerHTML = companyLogo
    ? `<img src="${companyLogo}" alt="${escapeHtml(settings.companyName)} logo" />`
    : `<span>${escapeHtml(settings.logoText.slice(0, 6))}</span>`;
  updateBrandingStatus();
}

function setTheme(theme) {
  const dark = theme === "dark";
  document.body.classList.toggle("dark-mode", dark);
  els.themeToggle.textContent = dark ? "Dark Mode" : "Light Mode";
  writeJson(STORAGE_KEYS.theme, theme);
}

function updateBrandingStatus() {
  const hasLogo = Boolean(localStorage.getItem(STORAGE_KEYS.companyLogo));
  const hasLetterhead = Boolean(localStorage.getItem(STORAGE_KEYS.letterheadPDF));
  els.brandingStatus.textContent = `Logo: ${hasLogo ? "stored" : "not stored"} | Letterhead PDF: ${hasLetterhead ? "stored" : "not stored"}`;
}

function fileToDataUrl(file) {
  return new Promise((resolve, reject) => {
    const reader = new FileReader();
    reader.onload = () => resolve(reader.result);
    reader.onerror = reject;
    reader.readAsDataURL(file);
  });
}

async function storeBrandingFile(file, key, successMessage) {
  if (!file) return;
  showLoading("Storing branding asset...");
  try {
    const base64String = await fileToDataUrl(file);
    localStorage.setItem(key, base64String);
    applySettings();
    renderAll(successMessage);
  } catch {
    els.recentActivity.textContent = "Branding upload failed";
  } finally {
    hideLoading();
  }
}

async function fetchAssetAsDataUrl(path) {
  const response = await fetch(path);
  if (!response.ok) throw new Error(`Unable to load ${path}`);
  const blob = await response.blob();
  return fileToDataUrl(blob);
}

async function preloadBundledBranding() {
  try {
    if (!localStorage.getItem(STORAGE_KEYS.companyLogo)) {
      const base64String = await fetchAssetAsDataUrl("./jm-logo.jpg");
      localStorage.setItem(STORAGE_KEYS.companyLogo, base64String);
    }
    if (!localStorage.getItem(STORAGE_KEYS.letterheadPDF)) {
      const base64PDF = await fetchAssetAsDataUrl("./jay-muldas-letterhead.pdf");
      localStorage.setItem(STORAGE_KEYS.letterheadPDF, base64PDF);
    }
    applySettings();
  } catch {
    updateBrandingStatus();
  }
}

function showLoading(message) {
  els.loadingOverlay.querySelector("span").textContent = message;
  els.loadingOverlay.hidden = false;
}

function hideLoading() {
  els.loadingOverlay.hidden = true;
}

function copyResults() {
  const calculated = getCalculatedWindows();
  const lines = calculated.map((win) => `${win.number}: ${win.sectionLabel}, FW ${formatNumber(win.frameHorizontal)}, FH ${formatNumber(win.frameVertical)}, GW ${formatNumber(win.glassWidth)}, GH ${formatNumber(win.glassHeight)}`);
  navigator.clipboard.writeText(lines.join("\n")).then(() => {
    els.copyStatus.textContent = "Copied";
    els.recentActivity.textContent = "Copied";
  }).catch(() => {
    els.copyStatus.textContent = "Copy unavailable";
  });
}

function printModule(target) {
  showLoading("Preparing print...");
  document.body.dataset.printTarget = target;
  window.setTimeout(() => {
    hideLoading();
    window.print();
    delete document.body.dataset.printTarget;
  }, 250);
}

function exportPdf() {
  saveProject();
  printModule("all");
}

function tableData(type) {
  const calculated = getCalculatedWindows();
  const cutting = buildCuttingSchedule(calculated);
  const material = buildMaterialSummary(calculated);
  const glass = buildGlassSummary(calculated);
  const quote = buildQuotation(calculated, material, glass);
  if (type === "calculations") return [["Window", "Section", "Width", "Height", "Qty", "Frame Vertical", "Frame Horizontal", "Shutter Vertical", "Shutter Horizontal", "Glass Width", "Glass Height", "Glass Area"], ...calculated.map((w) => [w.number, w.sectionLabel, w.width, w.height, w.quantity, w.frameVertical, w.frameHorizontal, w.shutterVertical, w.shutterHorizontal, w.glassWidth, w.glassHeight, w.glassAreaSqFt])];
  if (type === "cutting") return [["Group", "Window", "Member", "Cutting Size", "Quantity", "Total Length"], ...cutting.map((r) => [r.group, r.windowNo, r.member, r.size, r.quantity, r.total])];
  if (type === "material") return [["Material", "Total"], ...Object.entries(material)];
  if (type === "glass") return [["Glass Width", "Glass Height", "Quantity", "Total Area"], ...glass.map((g) => [g.width, g.height, g.quantity, g.area])];
  if (type === "quotation") return [["Cost Head", "Amount"], ["Aluminium Cost", quote.aluminiumCost], ["Glass Cost", quote.glassCost], ["Hardware Cost", quote.hardwareCost], ["Labour Cost", quote.labourCost], ["Other Charges", quote.otherCharges], ["Profit", quote.profit], ["GST", quote.gst], ["Grand Total", quote.grandTotal]];
  return [];
}

function exportCsv(type) {
  const csv = tableData(type).map((row) => row.map((cell) => `"${String(cell ?? "").replaceAll('"', '""')}"`).join(",")).join("\n");
  downloadFile(`${type}-export.csv`, csv, "text/csv");
}

function downloadFile(name, content, type) {
  const blob = new Blob([content], { type });
  const url = URL.createObjectURL(blob);
  const link = document.createElement("a");
  link.href = url;
  link.download = name;
  link.click();
  URL.revokeObjectURL(url);
}

function clearAll() {
  localStorage.removeItem(STORAGE_KEYS.projects);
  localStorage.removeItem(STORAGE_KEYS.history);
  localStorage.removeItem(STORAGE_KEYS.quotations);
  activeProject = createBlankProject();
  renderProjectForm();
  clearWindowForm();
  renderAll("Cleared");
}

function bindEvents() {
  els.sectionType.addEventListener("change", () => { syncTrackOptions(); syncBearingVisibility(); });
  els.addWindowButton.addEventListener("click", addWindow);
  els.updateWindowButton.addEventListener("click", updateWindow);
  els.clearWindowFormButton.addEventListener("click", () => clearWindowForm());
  els.windowRows.addEventListener("click", (event) => {
    const edit = event.target.closest("[data-window-edit]");
    const copy = event.target.closest("[data-window-copy]");
    const del = event.target.closest("[data-window-delete]");
    if (edit) editWindow(Number(edit.dataset.windowEdit));
    if (copy) duplicateWindow(Number(copy.dataset.windowCopy));
    if (del) deleteWindow(Number(del.dataset.windowDelete));
  });
  els.newProjectButton.addEventListener("click", () => { activeProject = createBlankProject(); renderProjectForm(); clearWindowForm(); renderAll("New project"); });
  els.saveProjectButton.addEventListener("click", () => saveProject());
  els.duplicateProjectButton.addEventListener("click", () => saveProject({ duplicate: true }));
  els.projectSearch.addEventListener("input", renderProjects);
  els.projectSelect.addEventListener("change", () => { if (els.projectSelect.value) openProject(els.projectSelect.value); });
  els.projectList.addEventListener("click", (event) => {
    const open = event.target.closest("[data-project-open]");
    const copy = event.target.closest("[data-project-copy]");
    const del = event.target.closest("[data-project-delete]");
    if (open) openProject(open.dataset.projectOpen);
    if (copy) duplicateSavedProject(copy.dataset.projectCopy);
    if (del) deleteProject(del.dataset.projectDelete);
  });
  [els.clientName, els.clientMobile, els.siteAddress, els.projectName, els.projectDate, els.projectRemarks, els.profitPercent, els.itemDescription].forEach((input) => input.addEventListener("input", () => renderAll()));
  els.copyButton.addEventListener("click", copyResults);
  els.pdfButton.addEventListener("click", exportPdf);
  document.querySelectorAll("[data-print-target]").forEach((button) => button.addEventListener("click", () => printModule(button.dataset.printTarget)));
  document.querySelectorAll("[data-export]").forEach((button) => button.addEventListener("click", () => exportCsv(button.dataset.export)));
  els.saveRatesButton.addEventListener("click", saveRates);
  els.resetRatesButton.addEventListener("click", resetRates);
  els.exportRatesButton.addEventListener("click", exportRates);
  els.importRatesInput.addEventListener("change", () => importRates(els.importRatesInput.files[0]));
  els.companyLogoInput.addEventListener("change", () => storeBrandingFile(els.companyLogoInput.files[0], STORAGE_KEYS.companyLogo, "Logo stored"));
  els.letterheadPdfInput.addEventListener("change", () => storeBrandingFile(els.letterheadPdfInput.files[0], STORAGE_KEYS.letterheadPDF, "Letterhead stored"));
  els.historySearch.addEventListener("input", renderHistory);
  els.historyFilter.addEventListener("change", renderHistory);
  els.historyList.addEventListener("click", (event) => {
    const open = event.target.closest("[data-history-open]");
    if (open) openProject(open.dataset.historyOpen);
  });
  els.saveSettingsButton.addEventListener("click", saveSettings);
  els.themeToggle.addEventListener("click", () => setTheme(document.body.classList.contains("dark-mode") ? "light" : "dark"));
  els.clearAllButton.addEventListener("click", clearAll);
}

function init() {
  populateSections();
  syncTrackOptions();
  syncBearingVisibility();
  renderRates();
  applySettings();
  preloadBundledBranding();
  setTheme(readJson(STORAGE_KEYS.theme, "light"));
  const activeId = readJson(STORAGE_KEYS.activeProject, null);
  const saved = getProjects().find((project) => project.id === activeId);
  if (saved) activeProject = structuredClone(saved);
  renderProjectForm();
  clearWindowForm();
  bindEvents();
  renderAll();
}

init();

window.aluminiumCalculator = {
  DEDUCTION_MASTER,
  calculateWindow,
  parseMeasurement,
  buildCuttingSchedule,
  buildMaterialSummary,
  buildGlassSummary,
};
